package javab8.com.day7.oop.modifier2;

import javab8.com.day7.oop.modifier.SuperClass;

public class CallClass {

	public static void main(String[] args) {
		
		SuperClass sc = new SuperClass();
		sc.biodata();
		
	}

}
