package javab8.com.day7.oop.modifier;

public class SubClass {

	public static void main(String[] args) {
		
		SuperClass sc = new SuperClass();
		
		sc.biodata();
		sc.salary();
		
	}

}
