package javab8.com.day7.task;

public class Arr1 {

	public static void main(String[] args) {

		// buat arraylist dengan berikut :
		
		// Jeruk
		// Aple
		// Mangga
		
		// setelah di print, buat syntax
		// ganti Mangga menjadi Timun
		// Print kembali

	}

}
