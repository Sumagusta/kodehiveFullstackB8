package javab8.com.day12.genericinterface;

public interface GenericInterface<T> {
	
	public T rumus(int a, double b);

}
