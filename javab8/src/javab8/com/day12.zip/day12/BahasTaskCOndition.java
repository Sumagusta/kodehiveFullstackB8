package javab8.com.day12;

public class BahasTaskCOndition {

	public static void main(String[] args) {

		int hadiah = 0;
		   int noJuara = 1;

		if (noJuara <= 3) {
				System.out.println(noJuara + "Dapat Uang 20 Juta");
				System.out.println(noJuara + "Dapat Uang 10 Juta");
				System.out.println(noJuara + "Dapat Uang 5 Juta");
			} else {
				System.out.println(noJuara + "Dapat Uang 1 Juta");
			}
			noJuara++;
		    System.out.println(hadiah);
	}

}
