package javab8.com.day9.implement;

// file yang digunakan utk menyimpan data abstrak
public interface Warisan {

	public String warisan1();// abstract / tidak berisi

	public String warisan2();

	public String warisan3();

	public String warisan4();

	public String warisan5();
	
	// mereka merupakan template method, 
	// yang bisa digunakan berkali-kali di berbagai class

}
