package javab8.com.day9.implement;

public class PenerimaWarisanKedua implements Warisan{
	
	public static void main(String[] args) {

	}

	@Override
	public String warisan1() {
		// TODO Auto-generated method stub
		return "Apartemen";
	}

	@Override
	public String warisan2() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String warisan3() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String warisan4() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String warisan5() {
		// TODO Auto-generated method stub
		return null;
	}
}
