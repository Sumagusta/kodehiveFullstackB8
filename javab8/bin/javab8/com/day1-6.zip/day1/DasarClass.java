package javab8.com.day1;

public class DasarClass {

	public static void main(String[] args) {		
		System.out.println("Hello World");
	}

}
