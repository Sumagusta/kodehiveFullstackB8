package javab8.com.day1;

public class DataType {

	public static void main(String[] args) {

		// PRIMETIV Category Data Type
		
		// Boolean
		boolean data1 = true;
		boolean data2 = false;
		
		// number
		
		// Byte - -128 s/d 127
		byte dataByte = 127;
		System.out.println("Max value Byte : " + Byte.MAX_VALUE);

		// Short : 32767
		short datsShort = 32000;
		System.out.println("Max value Short : " + Short.MAX_VALUE);
		
		// int 
		int dataInteger = 50000;
		Integer a = 0;
		System.out.println("Max value Integer : " + Integer.MAX_VALUE);
		
		//Floating-Point
		
		float dataDecimal = 2.333f;
		System.out.println("Max value Float : " + Float.MAX_VALUE);
		
		// double
		double dataeDecimalTertinggi = 3.9;
		System.out.println("Max value Float : " + Double.MAX_VALUE);
		
		// char
		char dataChar = 'a';
		System.out.println(dataChar);
		
		// NON PRIMITIVE
		
	}
}
