package javab8.com.day4.condition.latihan;

public class ElseIf {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	// Buatlah kondisi berdasarkan data berikut :
		// jika usia kurang dari sama dengan 3 tahun masuk PAUD
		// jika usia kurang dari 5 tahun masuk TK
		// jika usia kurang dari 7 tahun masuk SD
		
		// 8 menit
		
	}

}
