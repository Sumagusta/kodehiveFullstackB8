package javab8.com.day4.condition;

public class Condition1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int bulan = 1;
		
		if (bulan == 1) {
			System.out.println("Januari");
		} else {
			System.out.println("Bukan bulan Januari");
		}

	}

}
