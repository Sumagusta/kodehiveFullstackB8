package javab8.com.day4;

public class QuizBahas {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		String depan = "Rrrrr";
	    String	 belakang ="Jobs";	
	    int usia = 56;
	    
	    System.out.println("Hasilnya adalah");
	    System.out.println(depan+" "+usia+" "+belakang);
	    
	}

}
