package javab8.com.day2;

public class Loop1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// increment : ++
		// decrement : --
		
		// contoh perulangan decrement dari 15 ke 5
//		int i = 15;
//
//		while (i >= 5) {
//
//			System.out.println("Hari " + i);
//
//			i--; // i + 1
//		}

		// contoh perulangan increment 5 ke 15
		int i = 16;
		while (i <= 15) {
			System.out.println("Hari " + i);

			i++; // i + 1
		}

//		System.out.println();
//		while (i > 0) {			
//			System.out.println("Hari "+ numb);
//			numb--;
//			i--; // i + 1
//		}

	}

}
