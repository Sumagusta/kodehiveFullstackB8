package javab8.com.day2;

public class WhileTask {

	public static void main(String[] args) {
		
		// seseorang sedang berlari mengelilingi lapangan
		// 1. ia terus berlari kecuali ia sampai pada putaran ke 10
		// 		setiap kali perulangan ia akan minum 100 ml air
		
		
	}

}
