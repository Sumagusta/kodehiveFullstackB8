package javab8.com.day3;

public class DoWhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		boolean batas = true;
		int i = 0;
		do {
			System.out.println("Loop Do-While "+i);
			i++;
			
		} while (batas == true);
		
	}

}
