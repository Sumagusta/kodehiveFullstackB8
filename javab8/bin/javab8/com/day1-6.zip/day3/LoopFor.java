package javab8.com.day3;

import java.util.Iterator;

public class LoopFor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// untuk perulangan dengan iterasi yang pasti
		
		int batas = 5;
		for (int i = 0; i < batas; i++) {
			System.out.println(i);
		}
		
	}

}
