package javab8.com.day8.constructor;

public class KelasPunyaConstructor {

	public KelasPunyaConstructor() {
		System.out.println("Welcome To Kodehive");
	}
	
	public void bukanConstructor() {
		System.out.println("Java Fullstack");
	}
	
}
