package javab8.com.day8.constructor;

public class KelasPanggilConstructor {

	public static void main(String[] args) {

		KelasPunyaConstructor kpc = new KelasPunyaConstructor();
		kpc.bukanConstructor();
		

	}

}
