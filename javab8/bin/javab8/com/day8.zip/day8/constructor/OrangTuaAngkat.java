package javab8.com.day8.constructor;

public class OrangTuaAngkat {

	protected void aset4() {
		System.out.println("Kos-kos an");
	}
	
	private void aset5() {
		System.out.println("Perhiasan");
	}
}
