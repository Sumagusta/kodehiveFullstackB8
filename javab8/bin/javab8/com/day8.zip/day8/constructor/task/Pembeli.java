package javab8.com.day8.constructor.task;

public class Pembeli {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
