package javab8.com.day8.constructor.task;

public class Toko {
	// Buat constructor dan isikan, "Selamat Datang Di Toko Wijaya"
	// Lakukan pemanggilan toko ke class pembeli
	

}
