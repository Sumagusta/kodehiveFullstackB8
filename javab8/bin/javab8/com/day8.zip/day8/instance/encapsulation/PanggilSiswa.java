package javab8.com.day8.instance.encapsulation;

public class PanggilSiswa {

	public static void main(String[] args) {
		
		// instance
		Siswa siswaObj = new Siswa();
		siswaObj.setNama("Dono");
		
		System.out.println(siswaObj.getNama());

	}

}
