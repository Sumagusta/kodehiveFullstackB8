package javab8.com.day8.inheritance;

public class OrangTua {

	public void aset1() {
		System.out.println("Mobil Pajero");
	}

	public void aset2() {
		System.out.println("Rumah");
	}

	public void aset3() {
		System.out.println("Motor bebek");
	}
}
