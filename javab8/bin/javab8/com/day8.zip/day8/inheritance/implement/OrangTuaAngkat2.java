package javab8.com.day8.inheritance.implement;

public interface OrangTuaAngkat2 {

}
