package javab8.com.day8.inheritance;

import javab8.com.day8.constructor.OrangTuaAngkat;

public class AnakPertama extends OrangTuaAngkat  {

	public static void main(String[] args) {
		
		OrangTua or = new OrangTua();
		or.aset1();
		or.aset2();

		AnakPertama an = new AnakPertama();
		an.aset4();
	}

}
