package javab8.com.day11.abstractclass;

public class SubClass extends SuperClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SubClass a = new SubClass();
		System.out.println(a.rumus1(5, 7));
	}

	@Override
	public int rumus2() {
		// TODO Auto-generated method stub
		return 0;
	}

}
