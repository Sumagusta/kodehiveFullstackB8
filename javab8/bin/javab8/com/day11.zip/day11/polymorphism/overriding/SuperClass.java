package javab8.com.day11.polymorphism.overriding;

public class SuperClass {
	
	public void menu() {
		System.out.println("Ayam Bakar");
	}
	
	public void menu2() {
		System.out.println("Ikan Bakar");
	}

}
